/******/ (() => { // webpackBootstrap
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it uses a non-standard name for the exports (exports).
(() => {
var exports = __webpack_exports__;
/**
 * Echos the parameters passed to the function.
 *
 * @param {*} params the parameters passed to the function
 * @returns a successful response with the parameters
 */
async function main(params) {
  return {
    statusCode: 200,
    body: {
      params,
    },
  };
}

exports.main = main;

})();

module.exports = __webpack_exports__;
/******/ })()
;